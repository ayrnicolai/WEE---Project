﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Configuration;

public partial class Deals : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuery = "insert into Products (Product, Price, Quantity) values (@Product, @Price, @Quantity)";
            SqlCommand com = new SqlCommand(insertQuery, conn);

            com.Parameters.Add("@Product", "Flemming");
            com.Parameters.Add("@Price", 33);
            com.Parameters.AddWithValue("@Quantity", DropDownListFlemming.SelectedItem.ToString());


            com.ExecuteNonQuery();
            //    Response.Redirect("Manager.aspx");
            Response.Write("You added Flemming to your cart");


            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }
    }
}