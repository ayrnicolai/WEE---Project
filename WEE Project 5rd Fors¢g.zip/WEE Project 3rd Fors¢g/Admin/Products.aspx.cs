﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class Products : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click2(object sender, EventArgs e)
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuery = "insert into Products (Product, Price, Quantity) values (@Product, @Price, @Quantity)";
            SqlCommand com = new SqlCommand(insertQuery, conn);

            com.Parameters.Add("@Product", "Petra");
            com.Parameters.Add("@Price", 20);
            com.Parameters.AddWithValue("@Quantity", DropDownListPetRace.SelectedItem.ToString());

            com.ExecuteNonQuery();
            //    Response.Redirect("Manager.aspx");
            Response.Write("You added Petra to your cart");


            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }
    }
    protected void Button1_Click3(object sender, EventArgs e)
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuery = "insert into Products (Product, Price, Quantity) values (@Product, @Price, @Quantity)";
            SqlCommand com = new SqlCommand(insertQuery, conn);

            com.Parameters.Add("@Product", "Francisco");
            com.Parameters.Add("@Price", 50);
            com.Parameters.AddWithValue("@Quantity", DropDownListPetRaceFrancisco.SelectedItem.ToString());


            com.ExecuteNonQuery();
            //    Response.Redirect("Manager.aspx");
            Response.Write("You added Francisco to your cart");


            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }

    }
    protected void Button1_Click4(object sender, EventArgs e)
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuery = "insert into Products (Product, Price, Quantity) values (@Product, @Price, @Quantity)";
            SqlCommand com = new SqlCommand(insertQuery, conn);

            com.Parameters.Add("@Product", "Flemming");
            com.Parameters.Add("@Price", 33);
            com.Parameters.AddWithValue("@Quantity", DropDownListFlemming.SelectedItem.ToString());


            com.ExecuteNonQuery();
            //    Response.Redirect("Manager.aspx");
            Response.Write("You added Flemming to your cart");


            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }


    }
    protected void Button1_Click5(object sender, EventArgs e)
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuery = "insert into Products (Product, Price, Quantity) values (@Product, @Price, @Quantity)";
            SqlCommand com = new SqlCommand(insertQuery, conn);

            com.Parameters.Add("@Product", "Human Vimse");
            com.Parameters.Add("@Price", 32);
            com.Parameters.AddWithValue("@Quantity", DropDownListVimse.SelectedItem.ToString());


            com.ExecuteNonQuery();
            //    Response.Redirect("Manager.aspx");
            Response.Write("You added Human Vimse to your cart");


            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }

    }
    protected void Button1_Click6(object sender, EventArgs e)
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuery = "insert into Products (Product, Price, Quantity) values (@Product, @Price, @Quantity)";
            SqlCommand com = new SqlCommand(insertQuery, conn);

            com.Parameters.Add("@Product", "Wallplug");
            com.Parameters.Add("@Price", 4);
            com.Parameters.AddWithValue("@Quantity", DropDownListWallplug.SelectedItem.ToString());


            com.ExecuteNonQuery();
            //    Response.Redirect("Manager.aspx");
            Response.Write("You added Wallplug to your cart");


            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }

    }
}

