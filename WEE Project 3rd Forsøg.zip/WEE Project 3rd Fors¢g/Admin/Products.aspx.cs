﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class Products : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
          try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuery = "insert into Products (Petra, Amount) values (@Petra, @20)";
            SqlCommand com = new SqlCommand(insertQuery, conn);

            com.Parameters.Add("Petra", 1);
            com.Parameters.Add("@20", 20);
      

            com.ExecuteNonQuery();
            //    Response.Redirect("Manager.aspx");
            Response.Write("You added Petra to your cart");


            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }
    }
    protected void ButtonFrancisco_Click(object sender, EventArgs e)
    {
          try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuery = "insert into Products (Francisco, Amount) values (@Francisco, @50)";
            SqlCommand com = new SqlCommand(insertQuery, conn);

            com.Parameters.Add("Francisco", 1);
            com.Parameters.Add("@50", 50);
      

            com.ExecuteNonQuery();
            //    Response.Redirect("Manager.aspx");
            Response.Write("You added Francisco to your cart");


            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }
    }
    }

