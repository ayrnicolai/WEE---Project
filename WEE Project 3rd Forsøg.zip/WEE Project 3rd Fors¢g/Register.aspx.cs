﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Register : System.Web.UI.Page
{

    protected void CreateUserWizard2_CreatedUser(object sender, EventArgs e)
    {
        Roles.AddUserToRole(CreateUserWizard2.UserName, "User");

    }
}
