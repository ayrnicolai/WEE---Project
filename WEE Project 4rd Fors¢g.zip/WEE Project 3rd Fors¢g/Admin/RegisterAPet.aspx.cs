﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class RegisterAPet : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            //Hver gang vi trykker på submit laver den en et nyt grid, og gemmer det i det nye grid. Denne metode danner et passende ID, unikt for hver ny user som bliver lavet
            Guid newGUID = Guid.NewGuid();


            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuery = "insert into UserData (ID,PetName,Email,PetRace,Country) values (@ID, @PName, @email, @PetRace, @country)";
            SqlCommand com = new SqlCommand(insertQuery, conn);

            com.Parameters.AddWithValue("@ID", newGUID.ToString());
            com.Parameters.AddWithValue("@PName", TextBoxUN.Text);
            com.Parameters.AddWithValue("@email", TextBoxMail.Text);
            com.Parameters.AddWithValue("@PetRace", DropDownListPetRace.SelectedItem.ToString());
            com.Parameters.AddWithValue("@country", DropDownListCountry.SelectedItem.ToString());

            com.ExecuteNonQuery();
            //    Response.Redirect("Manager.aspx");
            Response.Write("Pet registration is succesful");


            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error:" + ex.ToString());
        }
    }
}
