﻿
Partial Class Giftcards
    Inherits System.Web.UI.Page

End Class
