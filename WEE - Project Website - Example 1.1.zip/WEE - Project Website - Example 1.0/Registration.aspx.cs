﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string checkuser = "select count(*) from UserData where Username='"+TextBoxUN.Text+"'";
            SqlCommand com = new SqlCommand(checkuser, conn);
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            if (temp == 1)
            {
                Response.Write("User already Exists");
            }

            conn.Close();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            //Hver gang vi trykker på submit laver den en et nyt grid, og gemmer det i det nye grid. Denne metode danner et passende ID, unikt for hver ny user som bliver lavet
            Guid newGUID = Guid.NewGuid();


            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuery = "insert into UserData (ID,Username,Email,Password,Country) values (@ID, @Uname, @email, @password, @country)";
            SqlCommand com = new SqlCommand(insertQuery, conn);

            com.Parameters.AddWithValue("@ID", newGUID.ToString());
            com.Parameters.AddWithValue("@Uname", TextBoxUN.Text);
            com.Parameters.AddWithValue("@email", TextBoxMail.Text);
            com.Parameters.AddWithValue("@password", TextBoxPassword.Text);
            com.Parameters.AddWithValue("@country", DropDownListCountry.SelectedItem.ToString());

            com.ExecuteNonQuery();
        //    Response.Redirect("Manager.aspx");
            Response.Write("Registration is succesful");


            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error:"+ex.ToString());
        }
    }
}