﻿CREATE TABLE [dbo].[UserData]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Username] NCHAR(20) NULL, 
    [Email] NCHAR(50) NULL, 
    [Password] NCHAR(20) NULL, 
    [Country] NCHAR(15) NULL
)
